magick.js is an optimized version of Twitters bootstrap.js.
